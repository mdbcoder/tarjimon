"""Local Edge TTS bridge. Only the extension background worker calls this API."""
import asyncio
import hashlib
import json
import sys
from pathlib import Path

if sys.version_info < (3, 11):
    raise RuntimeError('Edge TTS requires Python 3.11 or newer.')

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.edge-deps'))
import edge_tts
from aiohttp import web

VOICES = ('uz-UZ-MadinaNeural', 'uz-UZ-SardorNeural')
CACHE = ROOT / '.edge-cache'
LOCK = asyncio.Lock()


@web.middleware
async def local_only(request, handler):
    # No CORS: ordinary web pages cannot call this bridge, even on localhost.
    origin = request.headers.get('Origin', '')
    if request.host != '127.0.0.1:8765' or (origin and not origin.startswith('chrome-extension://')):
        raise web.HTTPForbidden()
    if request.method == 'POST' and (request.content_type != 'application/json' or
                                    request.headers.get('X-Uz-Dub') != '1'):
        raise web.HTTPForbidden()
    return await handler(request)


async def health(request):
    return web.json_response({'ok': True, 'service': 'udemy-uz-edge-tts', 'voices': VOICES})


async def synthesize(request):
    try:
        data = await request.json()
        text, voice = data.get('text'), data.get('voice')
        if not isinstance(text, str) or not text.strip() or len(text) > 5000 or voice not in VOICES:
            raise ValueError('Matn yoki ovoz noto\'g\'ri (ko\'pi bilan 5000 belgi).')
    except (ValueError, AttributeError):
        return web.json_response({'ok': False, 'error': 'Matn yoki ovoz noto\'g\'ri.'}, status=400)
    key = hashlib.sha256(json.dumps([voice, text], ensure_ascii=False).encode()).hexdigest()
    path = CACHE / (key + '.mp3')
    try:
        # Cached speech must not wait behind an unrelated slow network synthesis.
        try:
            audio = path.read_bytes()
        except FileNotFoundError:
            pass
        else:
            return web.Response(body=audio, content_type='audio/mpeg')
        async with asyncio.timeout(22):
            async with LOCK:
                CACHE.mkdir(exist_ok=True)
                if not path.exists():
                    chunks = []
                    async for chunk in edge_tts.Communicate(text, voice).stream():
                        if chunk['type'] == 'audio':
                            chunks.append(chunk['data'])
                    audio = b''.join(chunks)
                    if not audio:
                        raise RuntimeError('Ovoz kelmadi')
                    path.write_bytes(audio)
                    # Bound disk use to approximately 100 MB.
                    files = sorted(CACHE.glob('*.mp3'), key=lambda p: p.stat().st_mtime, reverse=True)
                    total = 0
                    for file in files:
                        total += file.stat().st_size
                        if total > 100 * 1024 * 1024 and file != path:
                            file.unlink(missing_ok=True)
                else:
                    audio = path.read_bytes()
        return web.Response(body=audio, content_type='audio/mpeg')
    except Exception as error:
        print('Edge TTS:', type(error).__name__, str(error), flush=True)
        return web.json_response({'ok': False, 'error': 'Edge ovozi olinmadi. Internetni tekshiring va qayta sinang.'}, status=502)


def make_app():
    app = web.Application(middlewares=[local_only], client_max_size=32000)
    app.router.add_get('/health', health)
    app.router.add_post('/tts', synthesize)
    return app


if __name__ == '__main__':
    web.run_app(make_app(), host='127.0.0.1', port=8765)
