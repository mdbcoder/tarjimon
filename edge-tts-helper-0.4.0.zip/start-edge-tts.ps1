# Udemy UZ Dub - mahalliy Edge TTS yordamchisini ishga tushiradi.
# Faqat ASCII belgilar: konsol kodlashiga bogliq bolmasin.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot

$Port = 8765
$Base = "http://127.0.0.1:$Port"

function Test-EdgeService {
    # PowerShell 5.1 WebException, PowerShell 7 HttpRequestException tashlaydi:
    # ikkalasini ham bir xil ushlaymiz.
    try {
        $health = Invoke-RestMethod -Uri "$Base/health" -TimeoutSec 2
        return ($health.service -eq 'udemy-uz-edge-tts')
    } catch {
        return $false
    }
}

function Test-PortBusy {
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $client.Connect('127.0.0.1', $Port)
        $client.Close()
        return $true
    } catch {
        return $false
    }
}

if (Test-EdgeService) {
    Write-Host 'Edge TTS allaqachon ishlayapti.'
    exit 0
}
if (Test-PortBusy) {
    throw "$Port port boshqa dastur tomonidan band. Osha dasturni yoping va qayta urinib koring."
}

# Python 3.11+ ni topamiz: avval py launcher, keyin PATH dagi python va python3.
$edgePython = $null
$probe = 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'
foreach ($candidate in @(
    @{ Exe = 'py';      Pre = @('-3') },
    @{ Exe = 'python';  Pre = @() },
    @{ Exe = 'python3'; Pre = @() }
)) {
    $command = Get-Command $candidate.Exe -ErrorAction SilentlyContinue
    if (!$command) { continue }
    $pre = [string[]]$candidate.Pre
    & $command.Source @pre -c $probe
    if ($LASTEXITCODE -ne 0) { continue }
    $resolved = & $command.Source @pre -c 'import sys; print(sys.executable)'
    if ($LASTEXITCODE -eq 0 -and $resolved) {
        $edgePython = ([string]($resolved | Select-Object -First 1)).Trim()
        break
    }
}
if (!$edgePython -or !(Test-Path -LiteralPath $edgePython)) {
    throw 'Python 3.11+ topilmadi. https://www.python.org/downloads/windows/ dan ornating va ornatishda "Add python.exe to PATH" ni belgilang.'
}
Write-Host "Python: $edgePython"

# Paketlar aynan shu interpretator bilan import bolishini tekshiramiz.
# Boshqa Python versiyasida ornatilgan .edge-deps ishlamaydi (aiohttp ikkilik moduli).
$depsOk = $false
if (Test-Path -LiteralPath '.edge-deps\edge_tts') {
    & $edgePython -c "import sys; sys.path.insert(0, '.edge-deps'); import edge_tts, aiohttp"
    $depsOk = ($LASTEXITCODE -eq 0)
    if (!$depsOk) { Write-Host 'Ornatilgan paketlar bu Python bilan mos emas. Qaytadan ornatiladi.' }
}
if (!$depsOk) {
    if (Test-Path -LiteralPath '.edge-deps') {
        try { Remove-Item -LiteralPath '.edge-deps' -Recurse -Force }
        catch { throw '.edge-deps papkasini ochirib bolmadi. Ishlab turgan Python jarayonini yoping va qayta urining.' }
    }
    & $edgePython -m pip install --target .edge-deps -r edge-requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'edge-tts paketini yuklashda xato. Internet va pip ishlashini tekshiring.' }
    & $edgePython -c "import sys; sys.path.insert(0, '.edge-deps'); import edge_tts, aiohttp"
    if ($LASTEXITCODE -ne 0) { throw 'Paketlar ornatildi, lekin import bolmadi. edge-tts-error.log ni tekshiring.' }
}

Start-Process -FilePath $edgePython `
    -ArgumentList ('"' + (Join-Path $PSScriptRoot 'edge-server.py') + '"') `
    -WorkingDirectory $PSScriptRoot -WindowStyle Hidden `
    -RedirectStandardOutput (Join-Path $PSScriptRoot 'edge-tts.log') `
    -RedirectStandardError (Join-Path $PSScriptRoot 'edge-tts-error.log')

for ($attempt = 0; $attempt -lt 12; $attempt++) {
    Start-Sleep -Milliseconds 500
    if (Test-EdgeService) {
        Write-Host 'Edge TTS ishga tushirildi. Kengaytmada Ovoz studiyasini oching.'
        exit 0
    }
}
throw 'Edge TTS ishga tushmadi. edge-tts-error.log faylini tekshiring.'
