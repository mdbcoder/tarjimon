@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-edge-tts.ps1"
if errorlevel 1 pause
