# O'zbekcha Edge ovozi — Windows

Bu yordamchi dastur **ixtiyoriy**. Kengaytma matn tarjimasini usiz ham bajaradi.
Microsoft Edge nutq xizmatidan foydalanadi; Azure hisobi yoki API kaliti kerak emas.
Internet va Python 3.11 yoki yangirog'i kerak.

1. Python'ni https://www.python.org/downloads/windows/ dan o'rnating.
   O'rnatishda **Add python.exe to PATH**ni belgilang.
2. `edge-tts-helper-0.4.0.zip`ni alohida papkaga oching.
3. `start-edge-tts.cmd`ni ikki marta bosing. Birinchi safar kerakli paketlar
   `.edge-deps`ga PyPI'dan yuklanadi. Yuklash muvaffaqiyatsiz bo'lsa xabar chiqadi.
4. Kengaytmaning **Ovoz studiyasi**da Madina yoki Sardorni tanlab sinang va saqlang.
5. Kompyuter qayta yoqilgach yordamchi dasturni yana ishga tushiring.

Xizmat faqat `127.0.0.1:8765`da ishlaydi. Internetdan kirish uchun port ochmang.
Audio `.edge-cache`da saqlanadi; kalitlar yoki Udemy hisobi yordamchi dasturga berilmaydi.
Muammo bo'lsa `edge-tts.log` va `edge-tts-error.log`ni tekshiring. Logni ulashishdan
oldin shaxsiy ma'lumot yo'qligini ko'ring. Xizmatni to'xtatish uchun Task Manager'da
aynan `edge-server.py`ni ishlatayotgan Python jarayonini tugating.

`edge-tts` norasmiy kutubxona; Microsoft xizmatidagi o'zgarish uning ishlashiga ta'sir qilishi mumkin.
Yordamchi dastur Windows uchun tayyorlangan. macOS/Linux uchun avtomatik o'rnatish sinovdan o'tmagan.
Muallif/aloqa: https://urik.uz
