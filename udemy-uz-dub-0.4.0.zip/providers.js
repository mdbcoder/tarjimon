// Shared provider metadata. Endpoints are fixed; API keys never choose a URL.
const Providers = Object.freeze({
  anthropic: { name: 'Anthropic (Claude)', base: 'https://api.anthropic.com/v1', keyUrl: 'https://console.anthropic.com/settings/keys' },
  gemini: { name: 'Google Gemini', base: 'https://generativelanguage.googleapis.com/v1beta', keyUrl: 'https://aistudio.google.com/apikey' },
  openai: { name: 'OpenAI (GPT)', base: 'https://api.openai.com/v1', keyUrl: 'https://platform.openai.com/api-keys' },
  openrouter: { name: 'OpenRouter', base: 'https://openrouter.ai/api/v1', keyUrl: 'https://openrouter.ai/settings/keys' },
  groq: { name: 'Groq', base: 'https://api.groq.com/openai/v1', keyUrl: 'https://console.groq.com/keys' },
});
const validProvider = id => Object.hasOwn(Providers, id);
if (typeof module !== 'undefined') module.exports = { Providers, validProvider };
