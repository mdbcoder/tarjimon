// Normalizes all providers to the translation engine's existing response format.
const AI = (() => {
  const noTemperature = new Set();
  const fail = (error, fatal = true) => ({ ok: false, fatal, error });
  async function profile(requested) {
    const data = await chrome.storage.local.get(['provider', 'providerKeys', 'providerModels', 'anthropicKey', 'model']);
    const provider = requested || data.provider || 'anthropic';
    if (!validProvider(provider)) throw new Error('Tarjima xizmati noto‘g‘ri.');
    return { provider, key: data.providerKeys?.[provider] || (provider === 'anthropic' ? data.anthropicKey : '') || '',
      model: data.providerModels?.[provider] || (provider === (data.provider || 'anthropic') ? data.model : '') || '' };
  }
  function headers(provider, key) {
    const h = { 'Content-Type': 'application/json' };
    if (provider === 'anthropic') Object.assign(h, { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' });
    else if (provider === 'gemini') h['x-goog-api-key'] = key;
    else h.Authorization = 'Bearer ' + key;
    return h;
  }
  const limits = res => ({
    tokensLeft: res.headers?.get('anthropic-ratelimit-tokens-remaining') ?? res.headers?.get('x-ratelimit-remaining-tokens') ?? null,
    tokensReset: res.headers?.get('anthropic-ratelimit-tokens-reset') ?? null,
    retryAfter: res.headers?.get('retry-after') ?? null,
  });
  async function request(url, init) {
    // Keep a fetch below the MV3 worker's 30-second response limit.
    return fetch(url, { ...init, credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(25000) });
  }
  function errorResponse(res, body, key) {
    let detail = body;
    try { const d = JSON.parse(body); detail = d.error?.message || d.message || body; } catch (_) {}
    detail = String(detail).split(key).join('[kalit yashirildi]').slice(0, 350);
    const status = res.status;
    return { ok: false, fatal: [400, 401, 402, 403, 404, 413, 422].includes(status),
      rateLimit: status === 429 || status === 529,
      error: `${status}: ${detail || 'Xizmat javob bermadi'}`, limits: limits(res) };
  }
  async function listModels(provider) {
    const p = await profile(provider);
    if (!p.key) return fail('API kaliti sozlanmagan.');
    const base = Providers[p.provider].base;
    let next = '', models = [];
    const seen = new Set();
    for (let page = 0; page < 20; page++) {
      const url = new URL(base + '/models');
      if (p.provider === 'anthropic') { url.searchParams.set('limit', '1000'); if (next) url.searchParams.set('after_id', next); }
      if (p.provider === 'gemini') { url.searchParams.set('pageSize', '1000'); if (next) url.searchParams.set('pageToken', next); }
      const res = await request(url.href, { headers: headers(p.provider, p.key) });
      if (!res.ok) return errorResponse(res, await res.text(), p.key);
      const data = await res.json();
      let list = p.provider === 'gemini' ? data.models : data.data;
      if (!Array.isArray(list)) throw new Error('Model ro‘yxati formati noto‘g‘ri.');
      if (p.provider === 'gemini') list = list.filter(m => m.supportedGenerationMethods?.includes('generateContent'));
      if (p.provider === 'openrouter') list = list.filter(m => !m.architecture?.output_modalities || m.architecture.output_modalities.includes('text'));
      if (p.provider === 'openai' || p.provider === 'groq') list = list.filter(m => !/embedding|whisper|tts|dall-e|image|audio|realtime|moderation|transcri|sora/i.test(m.id));
      models.push(...list.map(m => ({ id: p.provider === 'gemini' ? m.name?.replace(/^models\//, '') : m.id,
        name: m.displayName || m.display_name || m.name || m.id })));
      next = p.provider === 'gemini' ? data.nextPageToken : p.provider === 'anthropic' && data.has_more ? data.last_id : '';
      if (!next) break;
      if (seen.has(next) || page === 19) throw new Error('Model ro‘yxati juda katta yoki sahifalash xatosi.');
      seen.add(next);
    }
    models = [...new Map(models.filter(m => typeof m.id === 'string' && m.id).map(m => [m.id, m])).values()];
    return { ok: true, models: models.sort((a, b) => a.id.localeCompare(b.id)), provider: p.provider };
  }
  function build(p, args, withTemp) {
    const { model, system, messages, maxTokens, temperature } = args;
    const temp = withTemp && Number.isFinite(temperature) ? { temperature } : {};
    let path, body;
    if (p.provider === 'anthropic') {
      path = '/messages'; body = { model, system, messages, max_tokens: maxTokens, ...temp };
    } else if (p.provider === 'gemini') {
      path = '/models/' + encodeURIComponent(model.replace(/^models\//, '')) + ':generateContent';
      body = { systemInstruction: { parts: [{ text: system }] },
        contents: messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
        generationConfig: { maxOutputTokens: maxTokens, ...temp } };
    } else if (p.provider === 'openai') {
      path = '/responses'; body = { model, instructions: system, input: messages, max_output_tokens: maxTokens, store: false, ...temp };
    } else {
      path = '/chat/completions'; body = { model, messages: [{ role: 'system', content: system }, ...messages], ...temp,
        ...(p.provider === 'groq' ? { max_completion_tokens: maxTokens } : { max_tokens: maxTokens }) };
    }
    return { url: Providers[p.provider].base + path, body };
  }
  function normalize(provider, data) {
    let text = '', stopReason, usage = data.usage || {}, blocked = false;
    if (provider === 'anthropic') {
      text = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
      stopReason = data.stop_reason; blocked = stopReason === 'refusal';
    } else if (provider === 'gemini') {
      const c = data.candidates?.[0];
      text = (c?.content?.parts || []).filter(p => !p.thought && typeof p.text === 'string').map(p => p.text).join('');
      stopReason = c?.finishReason === 'MAX_TOKENS' ? 'max_tokens' : c?.finishReason;
      blocked = !!data.promptFeedback?.blockReason || ['SAFETY', 'RECITATION', 'BLOCKLIST', 'PROHIBITED_CONTENT'].includes(c?.finishReason);
      usage = { input_tokens: data.usageMetadata?.promptTokenCount, output_tokens: data.usageMetadata?.candidatesTokenCount };
    } else if (provider === 'openai') {
      const parts = (data.output || []).filter(o => o.type === 'message').flatMap(o => o.content || []);
      text = parts.filter(p => p.type === 'output_text').map(p => p.text).join('');
      blocked = parts.some(p => p.type === 'refusal');
      stopReason = data.incomplete_details?.reason === 'max_output_tokens' ? 'max_tokens' : data.status;
    } else {
      const choice = data.choices?.[0];
      text = choice?.message?.content || '';
      stopReason = choice?.finish_reason === 'length' ? 'max_tokens' : choice?.finish_reason;
      blocked = !!choice?.message?.refusal || choice?.finish_reason === 'content_filter';
      usage = { input_tokens: usage.prompt_tokens, output_tokens: usage.completion_tokens };
    }
    if (blocked) return fail('Xizmat bu matn uchun javob berishni rad etdi.');
    if (data.error) return fail('Xizmat javobida xato qaytdi. Model va hisob holatini tekshiring.');
    if (typeof text !== 'string' || (!text.trim() && stopReason !== 'max_tokens')) return fail('Xizmat bo‘sh javob qaytardi. Boshqa matn modelini tanlang.', false);
    return { ok: true, text, stopReason, usage };
  }
  async function complete(args) {
    if (typeof args.model !== 'string' || !args.model.trim() || args.model.length > 200 ||
        typeof args.system !== 'string' || !Array.isArray(args.messages) || !args.messages.length ||
        args.messages.length > 100 || args.messages.some(m => !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') ||
        JSON.stringify(args).length > 200000 || !Number.isInteger(args.maxTokens) || args.maxTokens < 16 || args.maxTokens > 32000 ||
        (args.temperature !== undefined && (!Number.isFinite(args.temperature) || args.temperature < 0 || args.temperature > 1))) {
      return fail('Model yoki tarjima so‘rovi noto‘g‘ri.');
    }
    const p = await profile(args.provider);
    if (!p.key) return fail('API kaliti sozlanmagan.');
    const tag = p.provider + ':' + args.model;
    for (let attempt = 0; attempt < 2; attempt++) {
      const { url, body } = build(p, args, !noTemperature.has(tag));
      const res = await request(url, { method: 'POST', headers: headers(p.provider, p.key), body: JSON.stringify(body) });
      if (!res.ok) {
        const error = await res.text();
        if (res.status === 400 && /temperature/i.test(error) && !noTemperature.has(tag) && attempt === 0) {
          noTemperature.add(tag); continue;
        }
        return errorResponse(res, error, p.key);
      }
      return { ...normalize(p.provider, await res.json()), limits: limits(res), provider: p.provider };
    }
  }
  return { profile, listModels, complete };
})();
