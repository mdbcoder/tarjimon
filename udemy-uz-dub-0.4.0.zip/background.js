importScripts('providers.js', 'ai-providers.js');
const storageReady = chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
const publicKeys = new Set(['provider', 'model', 'tuning', 'speechConfig', 'speechDict']);
const readable = key => typeof key === 'string' && (publicKeys.has(key) || /^tr:\d+$/.test(key));
let settingsQueue = Promise.resolve();
const queued = fn => { const run = settingsQueue.then(fn); settingsQueue = run.catch(() => {}); return run; };

async function timedFetch(url, init = {}) {
  return fetch(url, { ...init, credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(25000) });
}
async function subtitle(url) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || !/(^|\.)(udemy\.com|udemycdn\.com)$/.test(parsed.hostname) || !parsed.pathname.toLowerCase().endsWith('.vtt')) {
    return { ok: false, error: 'Subtitr manzili ruxsat etilmagan' };
  }
  const res = await timedFetch(parsed.href);
  if (!res.ok) return { ok: false, error: `Subtitr yuklanmadi (${res.status}). English subtitrini qayta yoqing.` };
  const text = await res.text();
  if (text.length > 5000000 || !text.includes('-->')) return { ok: false, error: 'Subtitr formati noto‘g‘ri yoki juda katta' };
  return { ok: true, text };
}
async function edgeTTS(msg) {
  if (!['uz-UZ-MadinaNeural', 'uz-UZ-SardorNeural'].includes(msg.voice) || typeof msg.text !== 'string' || !msg.text.trim() || msg.text.length > 5000) {
    return { ok: false, error: 'Ovoz yoki matn noto‘g‘ri (ko‘pi bilan 5000 belgi).' };
  }
  try {
    const res = await timedFetch('http://127.0.0.1:8765/tts', { method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Uz-Dub': '1' }, body: JSON.stringify({ text: msg.text, voice: msg.voice }) });
    if (!res.ok) {
      let detail = '';
      try {
        const body = await res.json();
        if (typeof body?.error === 'string') detail = body.error.slice(0, 350);
      } catch {}
      return { ok: false, error: `Edge TTS xatosi (${res.status})${detail ? ': ' + detail : ''}` };
    }
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (!bytes.length || bytes.length > 10000000) throw new Error('Audio hajmi noto‘g‘ri');
    let binary = '';
    for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
    return { ok: true, audio: btoa(binary) };
  } catch (_) {
    return { ok: false, error: 'Edge TTS bilan ulanish yo‘q. start-edge-tts.cmd faylini ishga tushiring va internetni tekshiring.' };
  }
}
async function settings(msg) {
  const provider = msg.provider || 'anthropic';
  if (!validProvider(provider)) throw new Error('Xizmat noto‘g‘ri.');
  const data = await chrome.storage.local.get(['provider', 'providerKeys', 'providerModels', 'anthropicKey', 'model']);
  const providerKeys = { ...(data.providerKeys || {}) };
  const providerModels = { ...(data.providerModels || {}) };
  if (data.anthropicKey && !providerKeys.anthropic) providerKeys.anthropic = data.anthropicKey;
  const active = data.provider || 'anthropic';
  if (data.model && !providerModels[active]) providerModels[active] = data.model;
  if (msg.action === 'select') {
    await chrome.storage.local.set({ provider, model: providerModels[provider] || '', providerKeys, providerModels });
  } else if (msg.action === 'key') {
    if (typeof msg.key !== 'string' || msg.key.length > 1000 || /\s/.test(msg.key)) throw new Error('API kaliti noto‘g‘ri.');
    if (msg.key) providerKeys[provider] = msg.key;
    else delete providerKeys[provider];
    await chrome.storage.local.set({ providerKeys });
    if (provider === 'anthropic') await chrome.storage.local.remove('anthropicKey');
  } else if (msg.action === 'model') {
    if (typeof msg.model !== 'string' || !msg.model.trim() || msg.model.length > 200 || /\s/.test(msg.model)) throw new Error('Model ID noto‘g‘ri.');
    providerModels[provider] = msg.model;
    await chrome.storage.local.set({ providerModels, ...(active === provider ? { model: msg.model } : {}) });
  } else if (msg.action !== 'status') throw new Error('Amal noto‘g‘ri.');
  const p = await AI.profile(provider);
  return { ok: true, provider, hasKey: !!p.key, model: p.model };
}
async function storageBridge(msg) {
  if (msg.action === 'get') {
    const keys = Array.isArray(msg.keys) ? msg.keys : [msg.keys];
    if (!keys.length || keys.length > 100 || !keys.every(readable)) throw new Error('Xotira kaliti ruxsat etilmagan.');
    return { ok: true, data: await chrome.storage.local.get(keys) };
  }
  if (msg.action === 'set') {
    if (!msg.data || typeof msg.data !== 'object' || Array.isArray(msg.data) ||
        !Object.keys(msg.data).length || !Object.keys(msg.data).every(k => /^tr:\d+$/.test(k)) || JSON.stringify(msg.data).length > 8000000) {
      throw new Error('Faqat tarjima keshi yozilishi mumkin.');
    }
    await chrome.storage.local.set(msg.data);
    return { ok: true };
  }
  throw new Error('Xotira amali ruxsat etilmagan.');
}
// Xato TURINI aniqlaymiz, lekin xom matnni QAYTARMAYMIZ: tashlangan xatoda
// API kaliti yoki boshqa sir bo'lishi mumkin.
function describe(error) {
  const kind = String(error?.name || '') + ' ' + String(error?.message || '');
  if (/failed to fetch|networkerror|load failed|err_|typeerror/i.test(kind)) {
    return 'Tarmoqqa chiqib bo‘lmadi. Internetni tekshiring; reklama bloklovchi (AdBlock, uBlock) ' +
      'yoki antivirus kengaytmasi so‘rovni to‘sayotgan bo‘lishi mumkin.';
  }
  if (/abort|timeout/i.test(kind)) {
    return 'Xizmat belgilangan vaqtda javob bermadi. Ulanishni tekshirib qayta urining.';
  }
  return 'So‘rov bajarilmadi. Ulanish, kalit va xizmat sozlamalarini tekshiring.';
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  const own = sender.id === chrome.runtime.id;
  const trusted = own && typeof sender.url === 'string' &&
    ['options.html', 'tts-lab.html'].some(path => sender.url === chrome.runtime.getURL(path));
  let udemy = false;
  try { const url = new URL(sender.url); udemy = own && !!sender.tab && url.origin === 'https://www.udemy.com'; } catch (_) {}
  if (!trusted && !udemy) { sendResponse({ ok: false, fatal: true, error: 'Manba ruxsat etilmagan.' }); return; }
  const run = async () => {
    await storageReady;
    if (msg.type === 'settings' && trusted) return queued(() => settings(msg));
    if (msg.type === 'storage') return storageBridge(msg);
    if (msg.type === 'edgeTTS') return edgeTTS(msg);
    if (msg.type === 'subtitle') return subtitle(msg.url);
    if (msg.type === 'models' && trusted) return AI.listModels(msg.provider);
    if (msg.type === 'complete') return AI.complete(msg.payload || {});
    if (msg.type === 'hasKey') return { ok: true, hasKey: !!(await AI.profile(msg.provider)).key };
    if (msg.type === 'openOptions') { await chrome.runtime.openOptionsPage(); return { ok: true }; }
    return { ok: false, error: 'Amal ruxsat etilmagan.' };
  };
  run().then(sendResponse).catch((error) => sendResponse({ ok: false, error: describe(error) }));
  return true;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const clean = Object.fromEntries(Object.entries(changes).filter(([key]) => publicKeys.has(key)));
  if (!Object.keys(clean).length) return;
  chrome.tabs.query({ url: 'https://www.udemy.com/*' }).then(tabs => {
    for (const tab of tabs) chrome.tabs.sendMessage(tab.id, { type: 'configChanged', changes: clean }).catch(() => {});
  }).catch(() => {});
});
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
