// Shared playback adapter: browser voices and locally generated Edge MP3 audio.
const UzTTS = (() => {
  const voices = [
    { name: 'uz-UZ-MadinaNeural', lang: 'uz-UZ', edge: true, label: 'Madina — o‘zbekcha (Edge)' },
    { name: 'uz-UZ-SardorNeural', lang: 'uz-UZ', edge: true, label: 'Sardor — o‘zbekcha (Edge)' },
  ];
  let active = null;
  function release(job) {
    if (job && job.url && job.owns) URL.revokeObjectURL(job.url);
  }
  function cancel() {
    const job = active;
    active = null;
    if (job) {
      job.audio?.pause();
      release(job);
    }
    globalThis.speechSynthesis?.cancel();
  }
  // Audioni oldindan tayyorlaydi. Qaytgan URL chaqiruvchiga tegishli:
  // uni speak(u) ga u.src orqali beriladi, bo'shatish ham chaqiruvchi zimmasida.
  async function prepare(text, voiceName) {
    const result = await chrome.runtime.sendMessage({ type: 'edgeTTS', text, voice: voiceName });
    if (!result?.ok) throw new Error(result?.error || 'Edge TTS javob bermadi');
    const bytes = Uint8Array.from(atob(result.audio), c => c.charCodeAt(0));
    return URL.createObjectURL(new Blob([bytes], { type: 'audio/mpeg' }));
  }
  function speak(u) {
    cancel();
    if (!u.voice?.edge) return globalThis.speechSynthesis.speak(u);
    // u.src berilgan bo'lsa audio allaqachon tayyor: tarmoq kutilmaydi.
    const job = { audio: null, url: u.src || null, owns: !u.src, paused: false };
    active = job;
    const finish = (error) => {
      if (active !== job) return;
      cancel();
      if (error) u.onerror?.({ error });
      else u.onend?.();
    };
    job.fail = finish;
    (async () => {
      try {
        if (!job.url) {
          const url = await prepare(u.text, u.voice.name);
          if (active !== job) { URL.revokeObjectURL(url); return; }
          job.url = url;
          job.owns = true;
        }
        const audio = job.audio = new Audio(job.url);
        audio.playbackRate = u.rate || 1;
        audio.preservesPitch = true;
        audio.volume = u.volume ?? 1;
        audio.onplaying = () => { if (active === job) u.onstart?.(); };
        audio.onended = () => finish(null);
        audio.onerror = () => finish('Audio ijro etilmadi');
        if (!job.paused) await audio.play();
      } catch (error) { finish(error.message); }
    })();
  }
  function pause() {
    if (active) { active.paused = true; active.audio?.pause(); }
    else globalThis.speechSynthesis?.pause();
  }
  function resume() {
    const job = active;
    if (job) {
      job.paused = false;
      job.audio?.play().catch(error => job.fail(error.message));
    } else globalThis.speechSynthesis?.resume();
  }
  function progress() {
    const audio = active?.audio;
    return audio && Number.isFinite(audio.duration) && audio.duration > 0
      ? { remaining: Math.max(0, audio.duration - audio.currentTime) / audio.playbackRate }
      : null;
  }
  return {
    getVoices: () => [...voices, ...(globalThis.speechSynthesis?.getVoices() || [])],
    createUtterance: (text, voice) => voice?.edge || typeof SpeechSynthesisUtterance === 'undefined' ? { text } : new SpeechSynthesisUtterance(text),
    cancel, speak, prepare, pause, resume, progress,
    addEventListener: (...args) => globalThis.speechSynthesis?.addEventListener(...args),
    removeEventListener: (...args) => globalThis.speechSynthesis?.removeEventListener(...args),
  };
})();
