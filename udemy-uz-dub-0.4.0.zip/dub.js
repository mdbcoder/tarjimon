// Dublyaj dvigateli. Video vaqtini kuzatadi, har segmentni o'z vaqtida
// o'qiydi va ustoz ovozini pasaytiradi.
//
// Oqim rejimi (flow, standart): audio oldindan tayyorlanadi, shuning uchun
// videoni to'xtatib turishga hojat qolmaydi. Nutq segmentga sig'masa video
// yumshoq sekinlashadi va kechikish qoplangach o'zi tiklanadi.
//
// mode: "flow"  — sekinlashuv + faqat og'ir kechikishda pauza (standart)
//       "speed" — hech qachon videoga tegmaydi, nutq keyingi segmentga kirib ketadi
//       "pause" — eski xatti-harakat: sig'masa video to'xtaydi

const UzDubPlayer = (() => {
  "use strict";
  const synth = typeof UzTTS !== 'undefined' ? UzTTS : globalThis.speechSynthesis;

  const DEFAULTS = {
    cps: 14.5,        // o'zbek nutqi, belgi/soniya — faqat taxmin uchun zaxira
    baseRate: 1.0,
    maxRate: 1.45,    // bundan tez o'qish quloqqa yoqimsiz
    duckVolume: 0.12, // nutq paytida ustoz ovozi
    mode: "flow",
    voiceName: "",
    lead: 0.15,       // segment boshlanishidan shuncha oldin gapira boshlaydi
    prefetch: 8,      // qisqa jumlalarda ham yetarli audio zaxirasi
    lateGrace: 1.5,   // segment oxiridan keyin shuncha soniya kech boshlash mumkin
    driftSoft: 0.4,   // shundan katta kechikishda video sekinlasha boshlaydi
    driftSpan: 2.0,   // shuncha soniya ichida to'liq sekinlashuvga yetadi
    driftHard: 8.0,   // flow rejimida oxirgi chora: shu yerda video kutadi
    minVideoRate: 0.65, // foydalanuvchi tezligiga nisbatan eng past oqim tezligi
  };

  const S = {
    on: false,
    video: null,
    segs: [],
    dict: null,
    cfg: { ...DEFAULTS },
    voice: null,

    speaking: false,
    curSeg: null,
    nextIndex: 0,
    pausedByUs: false,
    savedVolume: null,
    applyingVolume: false,
    userRate: 1,
    appliedRate: null,
    cache: new Map(),
    pumping: null,
    frameTime: null,
    frameSeconds: 1 / 60,
    speechRemaining: 0,
    speechStarted: false,
    buffering: false,
    waitingAudio: false,
    waitingTranslation: false,
    streaming: false,
    rafId: null,
    onChange: null,
    utterance: null,
    watchdog: null,
    resetWatchdog: null,
    generation: 0,
    queueGeneration: 0,
    error: null,
  };

  const revoke = (url) => {
    if (url && typeof URL !== "undefined" && URL.revokeObjectURL) URL.revokeObjectURL(url);
  };

  // ---------------------------------------------------------------- video

  function findVideo() {
    const vids = Array.from(document.querySelectorAll("video"));
    // Udemy sahifasida reklama/preview videolari ham bo'lishi mumkin
    return vids.find((v) => v.duration > 30) || vids.find((v) => v.src || v.currentSrc) || vids[0] || null;
  }

  function attach() {
    const v = findVideo();
    if (!v || v === S.video) return !!v;

    stopSpeaking();
    detach();
    S.video = v;
    S.userRate = v.playbackRate || 1;
    S.appliedRate = null;
    v.addEventListener("seeking", onSeek);
    v.addEventListener("volumechange", onVolumeChange);
    v.addEventListener("ratechange", onRateChange);
    v.addEventListener("pause", onPause);
    v.addEventListener("playing", onPlaying);
    v.addEventListener("waiting", onWaiting);
    return true;
  }

  function detach() {
    const v = S.video;
    if (!v) return;
    v.removeEventListener("seeking", onSeek);
    v.removeEventListener("volumechange", onVolumeChange);
    v.removeEventListener("ratechange", onRateChange);
    v.removeEventListener("pause", onPause);
    v.removeEventListener("playing", onPlaying);
    v.removeEventListener("waiting", onWaiting);
    S.video = null;
  }

  function onSeek() {
    S.waitingTranslation = false;
    S.pausedByUs = false;
    S.waitingAudio = false;
    stopSpeaking();
    ++S.queueGeneration;
    clearCache();
    if (S.video) resync(S.video.currentTime);
    pump();
  }

  function onPause() {
    // Pauza jumlani bekor qilmaydi: keyin aynan shu joyidan davom etadi.
    if (!S.pausedByUs && !S.video?.ended) { synth.pause?.(); clearTimeout(S.watchdog); }
  }
  function onWaiting() { S.buffering = true; synth.pause?.(); clearTimeout(S.watchdog); }
  function onPlaying() {
    S.buffering = false;
    if (S.speaking) { S.resetWatchdog?.(); synth.resume?.(); }
  }

  function onVolumeChange() {
    // Udemy o'z qiymatini tiklab qo'yishi mumkin — nutq paytida qaytadan pasaytiramiz
    if (S.applyingVolume || !S.speaking || !S.video) return;
    if (Math.abs(S.video.volume - S.cfg.duckVolume) < 0.001) return;
    S.savedVolume = S.video.volume;
    setVolume(S.cfg.duckVolume);
  }

  function setVolume(x) {
    if (!S.video) return;
    S.applyingVolume = true;
    S.video.volume = Math.max(0, Math.min(1, x));
    S.applyingVolume = false;
  }

  function duck() {
    if (!S.video) return;
    if (S.savedVolume === null) S.savedVolume = S.video.volume;
    setVolume(S.cfg.duckVolume);
  }

  function unduck() {
    if (!S.video || S.savedVolume === null) return;
    setVolume(S.savedVolume);
    S.savedVolume = null;
  }

  // ---------------------------------------------------------------- tezlik

  // Foydalanuvchi tanlagan tezlikni o'zimiznikidan ajratamiz: aks holda
  // sekinlashuv o'z-o'zini kuchaytirib yuboradi.
  function onRateChange() {
    if (!S.video) return;
    const rate = S.video.playbackRate || 1;
    if (S.appliedRate !== null && Math.abs(rate - S.appliedRate) < 0.005) return;
    S.userRate = rate;
    S.appliedRate = null;
  }

  function setVideoRate(x) {
    if (!S.video) return;
    const value = Math.max(0.25, Math.min(4, x));
    if (Math.abs((S.video.playbackRate || 1) - value) < 0.0001) return;
    S.appliedRate = value;
    S.video.playbackRate = value;
  }

  // Har soniyada cheklangan o'zgarish: jumlalar orasida tezlik sakramaydi.
  function smoothRate(target) {
    if (!S.video) return;
    const current = S.video.playbackRate || S.userRate;
    const step = S.userRate * (target < current ? 0.3 : 0.15) * S.frameSeconds;
    setVideoRate(current + Math.max(-step, Math.min(step, target - current)));
  }

  // Audio tugash vaqtini oldindan hisoblaymiz; kechikishni kutmaymiz.
  function adaptRate(late) {
    if (!S.video) return;
    const progress = synth.progress?.();
    const remaining = progress?.remaining ?? S.speechRemaining;
    const next = S.segs[S.nextIndex];
    const deadline = Math.max(S.curSeg?.end || 0, next?.start || 0);
    const available = Math.max(0, deadline - S.video.currentTime);
    let target = remaining > 0.05 ? available / (remaining + 0.15) : S.userRate;
    const k = Math.max(0, Math.min(1, (late - S.cfg.driftSoft) / Math.max(0.1, S.cfg.driftSpan)));
    target = Math.min(target, S.userRate * (1 - k * (1 - S.cfg.minVideoRate)));
    smoothRate(Math.max(S.userRate * S.cfg.minVideoRate, Math.min(S.userRate, target)));
  }

  function restoreRate() {
    if (S.video) setVideoRate(S.userRate);
  }

  // ---------------------------------------------------------------- audio navbati

  const canPrefetch = () => !!(S.voice && S.voice.edge && typeof synth.prepare === "function");

  function bufferReady() {
    const count = Math.min(3, Math.max(1, S.cfg.prefetch), S.segs.length - S.nextIndex);
    for (let i = S.nextIndex; i < S.nextIndex + count; i++) {
      if (!S.segs[i].uz) return true;
      const entry = S.cache.get(S.segs[i].id);
      if (!entry || entry.status === 'pending') return false;
      // A final error must reach the UI instead of keeping the video paused.
      if (entry.status === 'error') return true;
    }
    return true;
  }

  function clearCache() {
    for (const entry of S.cache.values()) { revoke(entry.url); entry.settle?.(); }
    S.cache.clear();
  }

  function trimCache() {
    const keep = new Set();
    for (let i = Math.max(0, S.nextIndex - 1); i < Math.min(S.segs.length, S.nextIndex + Math.max(1, S.cfg.prefetch)); i++) {
      keep.add(S.segs[i].id);
    }
    if (S.curSeg) keep.add(S.curSeg.id);
    for (const [id, entry] of S.cache) {
      if (keep.has(id)) continue;
      revoke(entry.url);
      entry.settle?.();
      S.cache.delete(id);
    }
  }

  // MP3 uzunligini o'lchaymiz: tezlikni cps taxminiga emas, aniq songa moslash uchun.
  function measure(url) {
    if (typeof Audio === "undefined") return Promise.resolve(null);
    return new Promise((resolve) => {
      const probe = new Audio();
      let timer = null;
      const done = (value) => {
        if (timer !== null) clearTimeout(timer);
        timer = null;
        probe.onloadedmetadata = null;
        probe.onerror = null;
        resolve(value);
      };
      timer = setTimeout(() => done(null), 4000);
      probe.preload = "metadata";
      probe.onloadedmetadata = () => done(Number.isFinite(probe.duration) && probe.duration > 0 ? probe.duration : null);
      probe.onerror = () => done(null);
      probe.src = url;
    });
  }

  // Ijro tartibida ketma-ket to'ldiradi: mahalliy xizmat so'rovlarni baribir
  // navbatga qo'yadi, shuning uchun parallel so'rov birinchi segmentni kechiktiradi.
  async function pump() {
    if (S.pumping === S.queueGeneration || !canPrefetch()) return;
    const generation = S.queueGeneration;
    S.pumping = generation;
    try {
      while (S.on && generation === S.queueGeneration) {
        const limit = Math.min(S.segs.length, S.nextIndex + Math.max(1, S.cfg.prefetch));
        let target = null;
        for (let i = Math.max(0, S.nextIndex); i < limit; i++) {
          if (!S.segs[i].uz) break;
          if (!S.cache.has(S.segs[i].id)) { target = S.segs[i]; break; }
        }
        if (!target) break;
        const entry = { status: "pending", url: null, duration: null, error: null, settle: null, ready: null };
        entry.ready = new Promise((resolve) => { entry.settle = resolve; });
        S.cache.set(target.id, entry);
        try {
          const text = UzSpeech.forSegment(target, S.voice, S.dict);
          let url;
          for (let attempt = 0; attempt < 2; attempt++) {
            try { url = await synth.prepare(text, S.voice.name); break; }
            catch (error) {
              if (generation !== S.queueGeneration || attempt === 1) throw error;
            }
          }
          if (generation !== S.queueGeneration || S.cache.get(target.id) !== entry) { revoke(url); entry.settle(); return; }
          entry.duration = await measure(url);
          if (generation !== S.queueGeneration || S.cache.get(target.id) !== entry) { revoke(url); entry.settle(); return; }
          entry.status = "ready";
          entry.url = url;
        } catch (error) {
          if (generation !== S.queueGeneration) { entry.settle(); return; }
          entry.status = "error";
          entry.error = error.message;
        }
        entry.settle();
        trimCache();
      }
    } finally {
      if (S.pumping === generation) S.pumping = null;
    }
  }

  // Birinchi segment audiosi tayyor bo'lguncha kutamiz, aks holda dublyaj
  // yoqilgan zahoti birinchi jumla o'tkazib yuborilishi mumkin.
  async function warmup(limit = 12000) {
    const seg = S.segs[S.nextIndex];
    if (!seg || !canPrefetch()) return;
    const entry = S.cache.get(seg.id);
    if (!entry || entry.status !== "pending") return;
    let timer = null;
    await Promise.race([entry.ready, new Promise((r) => { timer = setTimeout(r, limit); })]);
    if (timer !== null) clearTimeout(timer);
  }

  // ---------------------------------------------------------------- nutq

  function pickVoice() {
    const all = synth.getVoices();
    if (!all.length) return null;
    if (S.cfg.voiceName) {
      const exact = all.find((v) => v.name === S.cfg.voiceName);
      if (exact) return exact;
    }
    return all.find((v) => /^uz(?:[-_]|$)/i.test(v.lang)) ||
      all.find((v) => /^tr(?:[-_]|$)/i.test(v.lang)) || null;
  }

  function stopSpeaking() {
    S.utterance = null;
    clearTimeout(S.watchdog);
    S.watchdog = null;
    S.resetWatchdog = null;
    S.speechStarted = false;
    S.speechRemaining = 0;
    S.waitingAudio = false;
    S.buffering = false;
    if (S.speaking) {
      S.speaking = false;
      S.curSeg = null;
      try { synth.cancel(); } catch (_) {}
    }
    unduck();
    restoreRate();
    if (S.pausedByUs) {
      S.pausedByUs = false;
      if (S.video && S.video.paused && S.on) S.video.play().catch(() => {});
    }
    notify();
  }

  function speakSegment(seg, entry) {
    if (!S.voice) {
      S.voice = pickVoice();
      if (!S.voice) return;
    }

    const text = UzSpeech.forSegment(seg, S.voice, S.dict);
    if (!text) return;

    const next = S.segs[S.nextIndex + 1];
    const budget = Math.max(0.5, Math.max(seg.end, next?.start || 0) - Math.max(seg.start, S.video?.currentTime || 0));
    // Tayyor audio bo'lsa haqiqiy uzunlik, aks holda belgi/soniya taxmini.
    const estimate = entry && entry.duration ? entry.duration : text.length / S.cfg.cps;

    // Sig'masa tezlashtiramiz, lekin chegaradan oshmaymiz
    let rate = S.cfg.baseRate;
    if (estimate > budget) {
      rate = Math.min(S.cfg.maxRate, S.cfg.baseRate * (estimate / budget));
    }
    // Foydalanuvchi videoni 1.5x da ko'rsa, nutq ham shuncha tez bo'lishi kerak.
    // O'zimizning sekinlashuvimiz emas, aynan foydalanuvchi tezligi olinadi.
    const vRate = S.userRate || 1;

    const u = synth.createUtterance ? synth.createUtterance(text, S.voice) : new SpeechSynthesisUtterance(text);
    u.voice = S.voice;
    u.lang = S.voice.lang;
    u.rate = Math.max(0.5, Math.min(3, rate * vRate));
    u.volume = 1;
    if (entry && entry.url) u.src = entry.url;

    const finish = (error) => {
      if (S.utterance !== u) return;
      clearTimeout(S.watchdog);
      S.watchdog = null;
      S.resetWatchdog = null;
      S.utterance = null;
      S.error = error ? "Ovoz xatosi: " + error + ". Sozlamalar → Ovoz sinovida boshqa ovozni tanlang. Matn tarjimasi ishlashda davom etadi." : null;
      S.speaking = false;
      S.curSeg = null;
      S.speechStarted = false;
      S.speechRemaining = 0;
      unduck();
      if (S.cfg.mode !== "flow") restoreRate();
      if (S.pausedByUs) {
        S.pausedByUs = false;
        if (S.video && S.on) S.video.play().catch(() => {});
      }
      notify();
    };

    u.onend = () => finish(null);
    u.onerror = (event) => finish(event.error || "o'qib bo'lmadi");
    u.onstart = () => {
      // Zaxira yo'l: audio oldindan tayyorlanmagan bo'lsa ham video kutib qolmasin.
      if (S.utterance !== u) return;
      S.speechStarted = true;
      if ((S.video?.paused && !S.video.ended && !S.pausedByUs) || S.buffering) { synth.pause?.(); return; }
      if (S.pausedByUs) {
        S.pausedByUs = false;
        if (S.video && S.on) S.video.play().catch(() => {});
      }
    };

    synth.cancel();
    S.utterance = u;
    S.error = null;
    S.speaking = true;
    S.curSeg = seg;
    S.speechRemaining = estimate / u.rate;
    S.speechStarted = false;
    duck();

    try {
      const watchdog = () => {
        if (S.utterance !== u) return;
        if ((S.video?.paused && !S.video.ended && !S.pausedByUs) || S.buffering) {
          S.watchdog = setTimeout(watchdog, 1000); return;
        }
        finish("ovoz javob bermadi");
        synth.cancel();
      };
      S.resetWatchdog = () => {
        clearTimeout(S.watchdog);
        S.watchdog = setTimeout(watchdog, Math.max(35000, text.length / 5 * 1000 + 30000));
      };
      S.resetWatchdog();
      synth.speak(u);
    } catch (error) {
      finish(error.message);
    }
    notify();
  }

  // ---------------------------------------------------------------- sikl

  // Birinchi shunday i: segs[i].end > t
  function indexAfter(t) {
    let lo = 0;
    let hi = S.segs.length;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (S.segs[mid].end > t) hi = mid;
      else lo = mid + 1;
    }
    return lo;
  }

  function resync(t) {
    S.nextIndex = indexAfter(t);
    const seg = S.segs[S.nextIndex];
    // Yarmidan ko'pi o'tib ketgan segmentni boshdan o'qimaymiz
    if (seg?.uz && t > seg.start + (seg.end - seg.start) * 0.5) S.nextIndex++;
  }

  function tick(now) {
    S.rafId = requestAnimationFrame(tick);
    S.frameSeconds = Number.isFinite(now) && S.frameTime !== null
      ? Math.max(0, Math.min(0.1, (now - S.frameTime) / 1000)) : 1 / 60;
    S.frameTime = Number.isFinite(now) ? now : null;
    if (S.video && S.video.isConnected === false) {
      stopSpeaking();
      detach();
      attach();
    }
    if (S.on && !S.video) attach();
    const v = S.video;
    if (!S.on || !v) return;

    const t = v.currentTime;

    // Haqiqiy seek seeking hodisasida boshqariladi. Sekin kadrlarni seek deb
    // hisoblash fondagi oynada hali o'qilmagan jumlalarni yo'qotardi.

    if (S.speaking) {
      if ((v.paused && !v.ended && !S.pausedByUs) || S.buffering) return;
      if (S.speechStarted) S.speechRemaining = Math.max(0, S.speechRemaining - S.frameSeconds);
      const late = S.curSeg ? t - S.curSeg.end : 0;
      if (S.cfg.mode === "pause") {
        // Eski xatti-harakat: nutq sig'masa video kutadi
        if (S.curSeg && !v.paused && late >= 0) {
          S.pausedByUs = true;
          v.pause();
          notify();
        }
        return;
      }
      if (S.cfg.mode === "flow") {
        adaptRate(late);
        // Oxirgi chora: sekinlashuv ham yetmasa
        if (late > S.cfg.driftHard && !v.paused) {
          S.pausedByUs = true;
          v.pause();
          notify();
        }
      }
      return;
    }

    if (S.waitingTranslation) {
      const next = S.segs[S.nextIndex];
      if (S.streaming && next && !next.uz && !next.error) return;
      S.waitingTranslation = false;
      const resume = S.pausedByUs;
      S.pausedByUs = false;
      if (resume) v.play().catch(() => {});
      notify();
    }
    if ((v.paused && !S.waitingAudio) || S.buffering) return;

    pump();
    // Bir dona audio kelishi bilan play/pause qilmaymiz: oldinda zaxira to'lsin.
    if (S.waitingAudio && !bufferReady()) return;

    // Umidsiz kechikkan segmentlarni tashlab ketamiz
    let seg = S.segs[S.nextIndex];
    while (seg && !seg.uz && (!S.streaming || seg.error)) {
      S.nextIndex++;
      seg = S.segs[S.nextIndex];
    }
    while (S.cfg.mode !== "flow" && seg && t > seg.end + S.cfg.lateGrace) {
      S.nextIndex++;
      seg = S.segs[S.nextIndex];
    }
    if (!seg) { smoothRate(S.userRate); return; }
    if (t + S.cfg.lead < seg.start) { smoothRate(S.userRate); return; }
    if (!seg.uz) {
      if (S.cfg.mode === "flow" && !v.paused) {
        S.waitingTranslation = true; S.pausedByUs = true;
        v.pause(); notify();
      }
      return;
    }

    let entry = null;
    if (canPrefetch()) {
      entry = S.cache.get(seg.id);
      // Audio hali tayyor emas: videoni to'xtatmaymiz, keyingi kadrda qaraymiz
      if (!entry || entry.status === "pending") {
        if (S.cfg.mode === "flow") {
          smoothRate(S.userRate * S.cfg.minVideoRate);
          if (!v.paused) {
            S.waitingAudio = true; S.pausedByUs = true; v.pause(); notify();
          }
        }
        return;
      }
      if (S.waitingAudio) {
        S.waitingAudio = false; S.pausedByUs = false;
        v.play().catch(() => {});
      }
      if (entry.status === "error") {
        S.error = "Ovoz xatosi: " + entry.error + ". Sozlamalar → Ovoz sinovida boshqa ovozni tanlang. Matn tarjimasi ishlashda davom etadi.";
        S.nextIndex++;
        notify();
        return;
      }
    }

    speakSegment(seg, entry);
    S.nextIndex++;
    if (S.cfg.mode === "flow") adaptRate(0);
    pump();
  }

  function notify() {
    if (typeof S.onChange === "function") {
      S.onChange({
        on: S.on,
        speaking: S.speaking,
        paused: S.pausedByUs,
        waitingAudio: S.waitingAudio,
        waitingTranslation: S.waitingTranslation,
        segId: S.curSeg ? S.curSeg.id : null,
        hasVideo: !!S.video,
        hasVoice: !!S.voice,
        error: S.error,
      });
    }
  }

  // ---------------------------------------------------------------- API

  async function loadConfig() {
    const got = await (typeof UzStorage !== 'undefined' ? UzStorage : chrome.storage.local).get(["speechConfig", "speechDict"]);
    S.cfg = { ...DEFAULTS, ...(got.speechConfig || {}) };
    for (const [key, min, max] of [["cps", 1, 100], ["baseRate", 0.5, 3], ["maxRate", 0.5, 3],
      ["duckVolume", 0, 1], ["lead", 0, 1], ["prefetch", 0, 12],
      ["lateGrace", 0, 10], ["driftSoft", 0, 10], ["driftSpan", 0.1, 20],
      ["driftHard", 0.5, 60], ["minVideoRate", 0.5, 1]]) {
      if (!Number.isFinite(S.cfg[key]) || S.cfg[key] < min || S.cfg[key] > max) S.cfg[key] = DEFAULTS[key];
    }
    if (!["flow", "speed", "pause"].includes(S.cfg.mode)) S.cfg.mode = DEFAULTS.mode;
    S.cfg.maxRate = Math.max(S.cfg.baseRate, S.cfg.maxRate);
    S.cfg.driftHard = Math.max(S.cfg.driftSoft + 0.5, S.cfg.driftHard);
    S.dict = got.speechDict && Object.keys(got.speechDict).length
      ? got.speechDict
      : UzSpeech.DEFAULT_DICT;
    S.voice = pickVoice();
  }

  return {
    async enable(segs, onChange, { streaming = false } = {}) {
      const generation = ++S.generation;
      ++S.queueGeneration;
      if (!synth) return { ok: false, error: "Brauzer ovoz o'qishni qo'llamaydi. Matn tarjimasidan foydalanishingiz mumkin." };
      clearCache();
      S.streaming = streaming;
      S.waitingTranslation = false;
      S.segs = (segs || []).filter((s) =>
        Number.isFinite(s.start) && Number.isFinite(s.end) && s.end > s.start).sort((a, b) => a.start - b.start);
      S.onChange = onChange || null;

      if (!S.segs.some(s => typeof s.uz === 'string' && s.uz.trim())) return { ok: false, error: "Tarjima qilingan segment yo'q" };

      await loadConfig();
      if (generation !== S.generation) return { ok: false, error: "Dublyaj bekor qilindi" };

      if (!S.voice) {
        await new Promise((r) => {
          const done = () => {
            synth.removeEventListener("voiceschanged", changed);
            clearTimeout(timer);
            r();
          };
          const changed = () => { if (pickVoice()) done(); };
          const timer = setTimeout(done, 3000);
          synth.addEventListener("voiceschanged", changed);
        });
        S.voice = pickVoice();
      }
      if (generation !== S.generation) return { ok: false, error: "Dublyaj bekor qilindi" };
      if (!S.voice) {
        return { ok: false, error: "O'zbekcha yoki turkcha ovoz topilmadi. Matn tarjimasi uchun ovoz shart emas. Sozlamalar → Ovoz sinovida mavjud ovozni tanlab saqlang." };
      }

      if (!attach()) return { ok: false, error: "Video topilmadi" };

      S.on = true;
      S.frameTime = null;
      resync(S.video.currentTime);
      if (!S.rafId) S.rafId = requestAnimationFrame(tick);
      notify();

      // Birinchi segment audiosini ijro boshlanishidan oldin tayyorlaymiz
      pump();
      await warmup();
      if (generation !== S.generation) return { ok: false, error: "Dublyaj bekor qilindi" };
      return { ok: true, voice: S.voice.name };
    },

    disable(resumeVideo = true) {
      ++S.generation;
      ++S.queueGeneration;
      const resume = S.pausedByUs;
      const video = S.video;
      S.on = false;
      S.streaming = false;
      S.waitingTranslation = false;
      stopSpeaking();
      if (resumeVideo && resume && video?.paused) video.play().catch(() => {});
      if (S.rafId) {
        cancelAnimationFrame(S.rafId);
        S.rafId = null;
      }
      clearCache();
      detach();
      notify();
    },

    isOn: () => S.on,
    setStreaming(value) { S.streaming = !!value; if (S.on) pump(); },
    refresh() { if (S.on) pump(); },
    reload: loadConfig,
    voiceName: () => (S.voice ? S.voice.name : null),
  };
})();
