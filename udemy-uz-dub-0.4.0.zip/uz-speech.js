// O'zbek lotin matnini turkcha imloga o'giradi, toki turkcha TTS ovozi
// uni tanish tovushlar bilan o'qisin. Bu vaqtinchalik yechim: brauzerda
// o'zbek ovozi yo'q, turkcha esa tovush tizimi bo'yicha eng yaqini.

const UzSpeech = (() => {
  "use strict";

  // ---------------------------------------------------------------- sonlar

  const ONES = ["", "bir", "ikki", "uch", "to'rt", "besh", "olti", "yetti", "sakkiz", "to'qqiz"];
  const TENS = ["", "o'n", "yigirma", "o'ttiz", "qirq", "ellik", "oltmish", "yetmish", "sakson", "to'qson"];

  function under1000(n) {
    const out = [];
    const h = Math.floor(n / 100);
    const t = Math.floor((n % 100) / 10);
    const o = n % 10;
    if (h) out.push(h === 1 ? "yuz" : ONES[h] + " yuz");
    if (t) out.push(TENS[t]);
    if (o) out.push(ONES[o]);
    return out.join(" ");
  }

  function numberToUz(n) {
    n = Math.trunc(Math.abs(n));
    if (n === 0) return "nol";
    if (n > 999999999) return String(n);

    const out = [];
    const mil = Math.floor(n / 1000000);
    const thou = Math.floor((n % 1000000) / 1000);
    const rest = n % 1000;

    if (mil) out.push(under1000(mil) + " million");
    if (thou) out.push(thou === 1 ? "ming" : under1000(thou) + " ming");
    if (rest) out.push(under1000(rest));

    return out.join(" ");
  }

  // "11,000" / "11 000" / "1.5" ni so'z bilan yozadi
  function spellNumbers(text) {
    return text
      .replace(/\b([01]?\d|2[0-3]):([0-5]\d)\b/g, (_, h, m) =>
        "soat " + numberToUz(+h) + (Number(m) ? " dan " + numberToUz(+m) + " daqiqa o'tdi" : ""))
      .replace(/([$€])\s*(\d+(?:[.,]\d+)*)/g, (_, unit, amount) =>
        spellNumbers(amount) + (unit === "$" ? " dollar" : " yevro"))
      .replace(/(\d)\s*%/g, "$1 foiz")
      .replace(/\b\d{1,3}(?:\.\d{3}){2,}\b/g, m => numberToUz(Number(m.replace(/\./g, ""))))
      .replace(/\b\d{1,3}(?:[,\u00a0 ]\d{3})+\b/g, (m) => numberToUz(Number(m.replace(/[,\u00a0 ]/g, ""))))
      // kasr sonlar: 1.5 → bir nuqta besh
      .replace(/\b(\d+)[.,](\d+)\b(?!\d)/g, (m, a, b) => {
        // 11,000 kabi minglik ajratgichni son deb o'qiymiz
        if (b.length === 3 && /^0+$/.test(b)) return numberToUz(parseInt(a + b, 10));
        return numberToUz(parseInt(a, 10)) + " nuqta " + b.split("").map((d) => ONES[+d] || "nol").join(" ");
      })
      .replace(/\b\d+\b/g, (m) => /^0\d/.test(m)
        ? m.split("").map(d => ONES[+d] || "nol").join(" ") : numberToUz(parseInt(m, 10)));
  }

  // ---------------------------------------------------------------- lug'at

  // Inglizcha atamalar turkcha ovoz to'g'ri o'qiy oladigan shaklda.
  // Bu ro'yxatni sinov sahifasida tahrirlash mumkin.
  // Standart lug'at sohaga bog'lanmagan. Zarur atamalarni foydalanuvchi qo'shadi.
  const DEFAULT_DICT = {};

  function applyDict(text, dict) {
    // Birikmalar alohida so'zlardan avval almashtiriladi.
    const keys = Object.keys(dict).sort((a, b) => b.length - a.length);
    for (const k of keys) {
      const esc = k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const boundary = /^[\w]/.test(k) ? "\\b" : "";
      const re = new RegExp(boundary + esc + (/[\w]$/.test(k) ? "\\b" : ""), "g");
      text = text.replace(re, () => " " + dict[k] + " ");
    }
    return text;
  }

  // ---------------------------------------------------------------- harflar

  // Tartib muhim: o' va g' apostroflari olib tashlanishidan oldin ishlanadi.
  const LETTERS = [
    [/[\u2018\u2019\u02BB\u02BC\u0060\u00B4]/g, "'"], // apostroflarni birxillashtiramiz
    [/o'/g, "o"],
    [/g'/g, "g"],
    [/sh/g, "ş"],
    [/ch/g, "ç"],
    [/ts/g, "ts"],
    [/'/g, ""],   // tutuq belgisi
    [/q/g, "k"],  // turkchada q yo'q
    [/x/g, "h"],  // o'zbek x ≈ turkcha h
    [/w/g, "v"],
    [/j/g, "c"],  // turkcha c = /dʒ/
  ];

  function transliterate(text, dict) {
    let t = applyDict(text, dict || DEFAULT_DICT);
    t = spellNumbers(t);
    // Preserve acronyms and mixed-case product names in the fallback voice.
    t = t.split(/(\b[A-Z]{2,5}\b|\b[A-Za-z]*[a-z][A-Z][A-Za-z]*\b)/g).map((part, i) => {
      if (i % 2) return part;
      part = part.toLowerCase();
      for (const [re, to] of LETTERS) part = part.replace(re, to);
      return part;
    }).join("");
    return t.replace(/\s+/g, " ").trim();
  }

  function forVoice(text, voice, dict) {
    return /^tr(?:[-_]|$)/i.test(voice?.lang || "")
      ? transliterate(text, dict)
      : spellNumbers(applyDict(text, dict || DEFAULT_DICT)).replace(/\s+/g, " ").trim();
  }

  function forSegment(seg, voice, dict) {
    const text = typeof seg.speech === "string" && seg.speech.trim() && seg.speech.length <= 5000 && seg.speechSource === seg.uz
      ? seg.speech : seg.uz;
    return forVoice(text, voice, dict);
  }

  return { transliterate, forVoice, forSegment, numberToUz, spellNumbers, DEFAULT_DICT };
})();

if (typeof module !== "undefined") module.exports = UzSpeech;
