// Ovoz sinovi sahifasi. Saqlangan tarjimalarni o'qiydi, turkcha imloga
// o'girib ovoz bilan o'qitadi va haqiqiy davomiylikni o'lchaydi.

const $ = (id) => document.getElementById(id);
const synth = UzTTS;

const ASSUMED_CPS = 14.5; // panel ishlatayotgan taxmin

const state = {
  lectures: {},   // id -> segs
  segs: [],
  voices: [],
  dict: { ...UzSpeech.DEFAULT_DICT },
  measuring: false,
  cancel: false,
  lastCal: null,
  savedVoice: "",
  voiceChosen: false,
  selectedVoice: "",
  utterance: null,
  cancelSpeech: null,
};

function say(el, text, kind) {
  el.textContent = text;
  el.className = "msg" + (kind ? " " + kind : "");
}

// ------------------------------------------------------------------ ovozlar

function loadVoices() {
  if (state.measuring) return false;
  const selected = state.voiceChosen ? state.selectedVoice : state.savedVoice;
  const all = synth.getVoices();
  const priority = (v) => /^uz(?:[-_]|$)/i.test(v.lang) ? 0 : /^tr(?:[-_]|$)/i.test(v.lang) ? 1 : 2;
  state.voices = [...all].sort((a, b) => priority(a) - priority(b));
  const sel = $("voice");
  sel.textContent = "";
  for (const v of state.voices) sel.appendChild(voiceOption(v));
  if (all.some((v) => v.name === selected)) sel.value = selected;
  $("saveVoice").disabled = !all.length;
  $("testVoice").disabled = !all.length;
  if (!all.length) {
    say($("setupMsg"), "Brauzerda ovozlar topilmadi. Matn tarjimasi ishlaydi; ovoz uchun tizimdagi nutq paketlarini tekshiring.", "err");
    return false;
  }
  const matched = all.some((v) => priority(v) < 2);
  say($("setupMsg"), matched ? "Ovoz tanlang, sinang va saqlang." :
    "O'zbekcha yoki turkcha ovoz yo'q. Mavjud ovozni sinashingiz mumkin; o'zbekcha talaffuz sifati cheklangan.", matched ? "ok" : "");
  return true;
}
function voiceOption(v) {
  const o = document.createElement("option");
  o.value = v.name;
  o.textContent = v.label || `${v.name} (${v.lang})`;
  return o;
}

const currentVoice = () =>
  state.voices.find((v) => v.name === $("voice").value) || null;

$("voice").addEventListener("change", () => {
  state.voiceChosen = true;
  state.selectedVoice = $("voice").value;
  state.lastCal = null;
  return saveVoice();
});

// ------------------------------------------------------------------ nutq

function speak(text, { volume = 1, rate = 1 } = {}) {
  state.cancelSpeech?.();
  return new Promise((resolve, reject) => {
    const v = currentVoice();
    if (!v) { reject(new Error("Ovoz tanlanmagan")); return; }
    const u = synth.createUtterance(text, v);
    u.voice = v;
    u.lang = v.lang;
    u.rate = rate;
    u.volume = volume;
    let t0 = performance.now(), settled = false;
    const finish = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      state.utterance = null;
      state.cancelSpeech = null;
      if (error) reject(new Error(error));
      else resolve(Math.max(0.01, (performance.now() - t0) / 1000));
    };
    const timer = setTimeout(() => {
      finish("Ovoz javob bermadi. Boshqa ovozni tanlang.");
      synth.cancel();
    }, Math.max(35000, text.length / 5 * 1000 + 30000));
    state.cancelSpeech = () => { finish("To'xtatildi"); synth.cancel(); };
    state.utterance = u;
    u.onstart = () => { t0 = performance.now(); };
    u.onend = () => finish(null);
    u.onerror = (e) => finish(e.error || "ovoz xatosi");
    try {
      synth.cancel();
      synth.speak(u);
    } catch (error) { finish(error.message); }
  });
}

function busy(value) {
  state.measuring = value;
  for (const id of ["listen", "measure", "testVoice", "saveVoice", "voice", "lecture", "rate", "count", "saveDict", "resetDict", "saveCal"]) {
    $(id).disabled = value;
  }
}

$("testVoice").addEventListener("click", async () => {
  if (state.measuring) return;
  busy(true);
  try {
    const text = "Assalomu alaykum. Bugun ma'lumotlar bazasi bilan ishlashni o'rganamiz.";
    await speak(UzSpeech.forVoice(text, currentVoice(), state.dict), { rate: Number($("rate").value) });
    say($("setupMsg"), "Sinov tugadi. Talaffuz mos bo'lsa ovozni saqlang.", "ok");
  } catch (error) {
    say($("setupMsg"), "Ovoz xatosi: " + error.message, "err");
  } finally { busy(false); }
});

// Serialize writes so a slow earlier selection cannot overwrite the latest one.
let voiceSaveQueue = Promise.resolve();
function saveVoice() {
  const voice = currentVoice();
  if (!voice) return say($("setupMsg"), "Ovoz tanlanmagan.", "err");
  const baseRate = Number($("rate").value);
  voiceSaveQueue = voiceSaveQueue.then(async () => {
  try {
    const { speechConfig } = await chrome.storage.local.get("speechConfig");
    // Tezlik/ovoz o'zgarsa eski kalibrlash yangi ovozga qo'llanmaydi.
    const same = speechConfig?.voiceName === voice.name && speechConfig?.baseRate === baseRate;
    await chrome.storage.local.set({ speechConfig: {
      ...(speechConfig || {}), voiceName: voice.name, baseRate,
      cps: same ? speechConfig.cps : ASSUMED_CPS * baseRate,
    } });
    state.savedVoice = voice.name;
    state.lastCal = null;
    say($("setupMsg"), "Saqlandi: " + voice.name + ". Darsda dublyajni qayta yoqing.", "ok");
  } catch (error) { say($("setupMsg"), "Saqlanmadi: " + error.message, "err"); }
  });
  return voiceSaveQueue;
}
$("saveVoice").addEventListener("click", saveVoice);
// ------------------------------------------------------------------ ma'ruza

async function loadLectures() {
  const all = await chrome.storage.local.get(null);
  const sel = $("lecture");
  sel.textContent = "";

  const ids = Object.keys(all)
    .filter((k) => k.startsWith("tr:"))
    .map((k) => k.slice(3));

  if (!ids.length) {
    const o = document.createElement("option");
    o.value = "";
    o.textContent = "— saqlangan tarjima yo'q —";
    sel.appendChild(o);
    $("measure").disabled = true;
    return;
  }

  for (const id of ids) {
    const rec = all["tr:" + id];
    const segs = (Array.isArray(rec?.segs) ? rec.segs : []).filter((s) =>
      s && typeof s.uz === "string" && s.uz.trim() && Number.isFinite(s.start) && Number.isFinite(s.end) && s.end > s.start);
    state.lectures[id] = segs;
    const o = document.createElement("option");
    o.value = id;
    o.textContent = `${id} — ${segs.length} segment`;
    sel.appendChild(o);
  }

  sel.value = ids[0];
  state.segs = state.lectures[ids[0]];
  $("measure").disabled = false;
}

$("lecture").addEventListener("change", (e) => {
  state.segs = state.lectures[e.target.value] || [];
  $("table").hidden = true;
  $("verdict").style.display = "none";
});

$("rate").addEventListener("input", (e) => {
  $("rateVal").textContent = Number(e.target.value).toFixed(2).replace(/0$/, "");
});

// ------------------------------------------------------------------ o'lchash

$("stop").addEventListener("click", () => {
  state.cancel = true;
  state.cancelSpeech?.();
  synth.cancel();
  say($("measureMsg"), "To'xtatildi.");
});

// Uchta segmentni ovoz bilan o'qiydi — talaffuzni tez tekshirish uchun
$("listen").addEventListener("click", async () => {
  if (state.measuring) return;
  if (!state.segs.length) {
    say($("measureMsg"), "Bu ma'ruzada tarjima qilingan segment yo'q.", "err");
    return;
  }
  if (!currentVoice()) {
    say($("measureMsg"), "Ovoz tanlanmagan.", "err");
    return;
  }

  busy(true);
  state.cancel = false;
  $("listen").disabled = true;
  $("measure").disabled = true;

  const rate = parseFloat($("rate").value);
  const picked = state.segs.slice(0, 3);

  for (let i = 0; i < picked.length; i++) {
    if (state.cancel) break;
    const s = picked[i];
    const speech = UzSpeech.forSegment(s, currentVoice(), state.dict);
    say($("measureMsg"), `Eshitilmoqda ${i + 1}/${picked.length}:\n${s.uz}\n→ ${speech}`);
    try {
      await speak(speech, { volume: 1, rate });
    } catch (err) {
      state.cancel = true;
      say($("measureMsg"), "Ovoz xatosi: " + err.message, "err");
      break;
    }
    await new Promise((r) => setTimeout(r, 400));
  }

  busy(false);
  $("listen").disabled = false;
  $("measure").disabled = false;
  if (!state.cancel) say($("measureMsg"), "Namuna tugadi.", "ok");
});

$("measure").addEventListener("click", async () => {
  if (state.measuring) return;
  if (!state.segs.length) {
    say($("measureMsg"), "Bu ma'ruzada tarjima qilingan segment yo'q.", "err");
    return;
  }

  busy(true);
  state.cancel = false;
  state.lastCal = null;
  $("measure").disabled = true;
  $("listen").disabled = true;

  const rate = parseFloat($("rate").value);
  const n = Math.min(Math.max(1, Math.min(40, parseInt($("count").value, 10) || 12)), state.segs.length);

  // Har xil uzunlikdagi segmentlarni olamiz, faqat boshidagilarni emas
  const step = Math.max(1, Math.floor(state.segs.length / n));
  const picked = [];
  for (let i = 0; i < state.segs.length && picked.length < n; i += step) {
    picked.push(state.segs[i]);
  }

  const tbody = $("table").querySelector("tbody");
  tbody.textContent = "";
  $("table").hidden = false;

  const rows = [];
  let totalChars = 0;
  let totalSecs = 0;

  for (let i = 0; i < picked.length; i++) {
    if (state.cancel) break;
    const s = picked[i];
    const speech = UzSpeech.forSegment(s, currentVoice(), state.dict);
    const videoDur = s.end - s.start;

    say($("measureMsg"), `O'lchanmoqda — ${i + 1}/${picked.length}`);

    let secs;
    try {
      secs = await speak(speech, { volume: 0, rate });
    } catch (err) {
      state.cancel = true;
      say($("measureMsg"), "Ovoz xatosi: " + err.message, "err");
      break;
    }

    totalChars += speech.length;
    totalSecs += secs;
    rows.push({ seg: s, speech, videoDur, secs });
    addRow(tbody, s, speech, videoDur, secs, rate);
  }

  busy(false);
  $("measure").disabled = false;
  $("listen").disabled = false;

  if (!rows.length || state.cancel) return;

  const cps = totalChars / totalSecs;
  const over = rows.filter((r) => r.secs > r.videoDur).length;

  // Barcha segmentlar uchun bashorat
  const allOver = state.segs.filter(
    (s) => s.uz.length / cps > (s.end - s.start)
  ).length;

  // Sig'ishi uchun kerak bo'lgan o'rtacha tezlik
  const needed = rows.reduce((a, r) => a + Math.max(1, r.secs / r.videoDur), 0) / rows.length;

  $("vCps").textContent = `${cps.toFixed(1)} belgi/soniya (${rate}× tezlikda)`;
  $("vOver").textContent =
    `${over}/${rows.length} o'lchanganda · butun ma'ruzada taxminan ${allOver}/${state.segs.length}`;
  $("vRate").textContent = (rate * needed).toFixed(2) + "×";

  let note;
  if (allOver / state.segs.length < 0.1) {
    note = "Nutq video vaqtiga bemalol sig'adi. Videoni to'xtatib turish kerak bo'lmaydi.";
  } else if (allOver / state.segs.length < 0.3) {
    note = "Ko'p segment sig'adi. Sig'maganlarini tezlikni biroz oshirib yopish mumkin.";
  } else {
    note = "Segmentlarning katta qismi sig'maydi. Tezlikni oshirish yoki dublyaj paytida videoni qisqa to'xtatib turish kerak bo'ladi.";
  }
  $("vNote").textContent = note;
  $("verdict").style.display = "block";

  state.lastCal = { cps, voiceName: $("voice").value, baseRate: rate };
  say($("calMsg"), "");

  say(
    $("measureMsg"),
    `Tugadi. Panel ${ASSUMED_CPS} deb taxmin qilgan edi, haqiqiy qiymat ${cps.toFixed(1)}.`,
    "ok"
  );
});

$("saveCal").addEventListener("click", async () => {
  if (!state.lastCal) {
    say($("calMsg"), "Avval o'lchashni bajaring.", "err");
    return;
  }
  const { speechConfig } = await chrome.storage.local.get("speechConfig");
  const cfg = {
    ...(speechConfig || {}),
    cps: Number(state.lastCal.cps.toFixed(2)),
    voiceName: state.lastCal.voiceName,
    baseRate: state.lastCal.baseRate,
  };
  await chrome.storage.local.set({ speechConfig: cfg });
  say(
    $("calMsg"),
    `Saqlandi: ${cfg.cps} belgi/soniya, ovoz "${cfg.voiceName}", tezlik ${cfg.baseRate}×.`,
    "ok"
  );
});

function addRow(tbody, s, speech, videoDur, secs, rate) {
  const tr = document.createElement("tr");
  const ratio = secs / videoDur;
  if (ratio > 1) tr.className = "over";
  else if (ratio > 0.9) tr.className = "tight";

  const tdId = document.createElement("td");
  tdId.className = "num";
  tdId.textContent = s.id;

  const tdText = document.createElement("td");
  tdText.textContent = s.uz;
  const small = document.createElement("span");
  small.className = "tr";
  small.textContent = speech;
  tdText.appendChild(small);

  const tdVideo = document.createElement("td");
  tdVideo.className = "num";
  tdVideo.textContent = videoDur.toFixed(1) + "s";

  const tdSpeech = document.createElement("td");
  tdSpeech.className = "num measured";
  tdSpeech.textContent = secs.toFixed(1) + "s";

  const tdRatio = document.createElement("td");
  tdRatio.className = "num";
  tdRatio.textContent = ratio.toFixed(2) + "×";

  const tdPlay = document.createElement("td");
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "Eshitish";
  btn.addEventListener("click", async () => {
    if (state.measuring) return;
    busy(true);
    try { await speak(UzSpeech.forSegment(s, currentVoice(), state.dict), { volume: 1, rate }); }
    catch (error) { say($("measureMsg"), error.message, "err"); }
    finally { busy(false); }
  });
  tdPlay.appendChild(btn);

  tr.append(tdId, tdText, tdVideo, tdSpeech, tdRatio, tdPlay);
  tbody.appendChild(tr);
}

// ------------------------------------------------------------------ lug'at

function dictToText(d) {
  return Object.entries(d)
    .map(([k, v]) => `${k} = ${v}`)
    .join("\n");
}

function textToDict(text) {
  const d = {};
  for (const line of text.split("\n")) {
    const i = line.indexOf("=");
    if (i === -1) continue;
    const k = line.slice(0, i).trim();
    const v = line.slice(i + 1).trim();
    if (k && v) d[k] = v;
  }
  return d;
}

$("saveDict").addEventListener("click", async () => {
  const d = textToDict($("dict").value);
  const n = Object.keys(d).length;
  state.dict = d;
  await chrome.storage.local.set({ speechDict: d });
  say($("dictMsg"), `${n} ta atama saqlandi.`, "ok");
});

$("resetDict").addEventListener("click", async () => {
  state.dict = { ...UzSpeech.DEFAULT_DICT };
  $("dict").value = dictToText(state.dict);
  await chrome.storage.local.remove("speechDict");
  say($("dictMsg"), "Standart bo'sh lug'atga qaytarildi.", "ok");
});

// ------------------------------------------------------------------ start

(async () => {
  const { speechDict, speechConfig } = await chrome.storage.local.get(["speechDict", "speechConfig"]);
  state.savedVoice = speechConfig?.voiceName || "";
  $("rate").value = speechConfig?.baseRate || 1;
  $("rateVal").textContent = $("rate").value;
  if (speechDict && Object.keys(speechDict).length) state.dict = speechDict;
  $("dict").value = dictToText(state.dict);

  await loadLectures();

  if (!synth) {
    say($("setupMsg"), "Bu brauzer ovoz o'qishni qo'llamaydi.", "err");
    for (const id of ["saveVoice", "testVoice", "measure", "listen"]) $(id).disabled = true;
    return;
  }
  loadVoices();
  synth.addEventListener("voiceschanged", loadVoices);
})();
