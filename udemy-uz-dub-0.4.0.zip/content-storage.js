const UzStorage = {
  async get(keys) {
    const res = await chrome.runtime.sendMessage({ type: 'storage', action: 'get', keys });
    if (!res?.ok) throw new Error(res?.error || 'Xotira javob bermadi');
    return res.data;
  },
  async set(data) {
    const res = await chrome.runtime.sendMessage({ type: 'storage', action: 'set', data });
    if (!res?.ok) throw new Error(res?.error || 'Xotira saqlanmadi');
  },
};
