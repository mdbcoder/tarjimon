const $ = id => document.getElementById(id);
const TUNING_DEFAULTS = { translationMode: 'whole', batchSize: 10, lengthRatio: 1.05, gapMs: 300, concurrency: 2, temperature: 0.2 };
let provider = 'anthropic', currentModel = '', epoch = 0, hasKey = false, loadingModels = false;
function say(el, text, kind = '') { el.textContent = text; el.className = 'msg ' + kind; }
function markStep(id, done) { $(id).classList.toggle('done', !!done); }
async function send(msg) {
  const res = await chrome.runtime.sendMessage(msg);
  if (!res?.ok) throw new Error(res?.error || 'Background javob bermadi. Kengaytmani Reload qiling.');
  return res;
}
function controls(disabled) {
  for (const id of ['provider', 'saveKey', 'clearKey', 'loadModels', 'model', 'saveManualModel', 'testRun']) $(id).disabled = disabled;
  $('loadModels').disabled = disabled || !hasKey;
  $('testRun').disabled = disabled || !hasKey || !currentModel;
}
function showProfile(p) {
  hasKey = !!p.hasKey;
  currentModel = p.model || '';
  $('keyState').textContent = p.hasKey ? 'saqlangan' : 'saqlanmagan';
  $('keyState').className = p.hasKey ? 'saved' : 'missing';
  $('modelState').textContent = currentModel || 'tanlanmagan';
  $('modelState').className = currentModel ? 'saved' : 'missing';
  $('loadModels').disabled = !p.hasKey || loadingModels;
  $('testRun').disabled = !p.hasKey || !currentModel;
  markStep('step1', p.hasKey); markStep('step2', currentModel); markStep('step3', false);
}
function modelOption(id, name = id) {
  const opt = document.createElement('option'); opt.value = id; opt.textContent = name; return opt;
}
async function refresh() {
  const token = epoch, id = provider;
  const p = await send({ type: 'settings', action: 'status', provider: id });
  if (token === epoch) showProfile(p);
}
// Every async handler owns a provider snapshot. A late response never overwrites a different provider.
function on(id, event, messageId, handler) {
  $(id).addEventListener(event, async e => {
    const token = epoch;
    try { await handler(e); }
    catch (error) { if (token === epoch) say($(messageId), error.message, 'err'); }
  });
}
on('provider', 'change', 'keyMsg', async e => {
  const id = e.target.value;
  if (!validProvider(id)) return;
  ++epoch; controls(true);
  try {
    const p = await send({ type: 'settings', action: 'select', provider: id });
    provider = id;
    $('key').value = ''; $('manualModel').value = ''; $('sample').style.display = 'none';
    $('keyLink').href = Providers[id].keyUrl;
    $('model').replaceChildren(modelOption(p.model || '', p.model || '— ro‘yxatni yuklang —'));
    for (const name of ['keyMsg', 'modelMsg', 'testMsg']) say($(name), '');
    controls(false); showProfile(p);
    if (p.hasKey) await loadModels();
  } catch (error) {
    $('provider').value = provider; controls(false); await refresh();
    say($('keyMsg'), error.message, 'err');
  }
});
on('saveKey', 'click', 'keyMsg', async () => {
  const key = $('key').value.trim(), id = provider, token = epoch;
  if (!key || /\s/.test(key)) throw new Error('API kalitini bo‘shliqlarsiz kiriting.');
  const p = await send({ type: 'settings', action: 'key', provider: id, key });
  if (token !== epoch) return;
  $('key').value = ''; showProfile(p); say($('keyMsg'), 'Kalit saqlandi.', 'ok');
  await loadModels();
});
on('clearKey', 'click', 'keyMsg', async () => {
  const token = epoch;
  const p = await send({ type: 'settings', action: 'key', provider, key: '' });
  if (token !== epoch) return;
  $('key').value = ''; showProfile(p); say($('keyMsg'), 'Tanlangan xizmat kaliti o‘chirildi.', 'ok');
});
async function saveModel(model, id = provider, token = epoch) {
  const p = await send({ type: 'settings', action: 'model', provider: id, model });
  if (token !== epoch) return;
  showProfile(p); say($('modelMsg'), 'Model saqlandi: ' + model, 'ok');
}
async function loadModels() {
  const id = provider, token = epoch;
  loadingModels = true; controls(true); say($('modelMsg'), 'Modellar yuklanmoqda…');
  try {
    const res = await send({ type: 'models', provider: id });
    if (token !== epoch) return;
    if (!res.models?.length) throw new Error('Matn modeli topilmadi. Model ID ni qo‘lda kiritishingiz mumkin.');
    const options = res.models.map(m => modelOption(m.id, !m.name || m.name === m.id ? m.id : m.name + ' — ' + m.id));
    if (!currentModel) options.unshift(modelOption('', '— modelni tanlang —'));
    else if (!res.models.some(m => m.id === currentModel)) options.unshift(modelOption(currentModel, currentModel + ' (saqlangan)'));
    $('model').replaceChildren(...options);
    $('model').value = currentModel;
    say($('modelMsg'), `${res.models.length} ta model yuklandi. ${currentModel ? 'Tanlangan model saqlab qolindi.' : 'Tarjima modelini tanlang.'}`, 'ok');
  } catch (error) {
    if (token === epoch) say($('modelMsg'), error.message + ' Ro‘yxatni qayta yuklang yoki Model ID ni qo‘lda kiriting.', 'err');
  } finally {
    if (token === epoch) {
      loadingModels = false; controls(false);
    }
  }
}
on('loadModels', 'click', 'modelMsg', loadModels);
on('model', 'change', 'modelMsg', async e => {
  const model = e.target.value;
  if (!model) { $('model').value = currentModel; return; }
  try { await saveModel(model); }
  catch (error) { $('model').value = currentModel; throw error; }
});
on('saveManualModel', 'click', 'modelMsg', async () => {
  const model = $('manualModel').value.trim(), token = epoch;
  await saveModel(model);
  if (token === epoch) $('model').replaceChildren(modelOption(model));
});
const TEST_EN = 'In this lesson, we will explore the main ideas and put them into practice with a simple example.';
on('testRun', 'click', 'testMsg', async () => {
  const token = epoch, id = provider, model = currentModel;
  if (!model) throw new Error('Avval modelni tanlang.');
  controls(true); $('sample').style.display = 'none'; say($('testMsg'), 'So‘rov yuborilmoqda…');
  try {
    const res = await send({ type: 'complete', payload: { provider: id, model,
      system: 'Inglizcha matnni tabiiy o‘zbek lotin tiliga tarjima qil. Faqat JSON massiv qaytar: [{"id":0,"uz":"..."}]',
      messages: [{ role: 'user', content: JSON.stringify([{ id: 0, en: TEST_EN }]) }], maxTokens: 4000, temperature: 0.2 } });
    if (token !== epoch) return;
    if (res.stopReason === 'max_tokens') throw new Error('Javob kesildi. Boshqa modelni sinang.');
    let arr;
    try { const raw = res.text.trim(); arr = JSON.parse(raw.slice(raw.indexOf('['), raw.lastIndexOf(']') + 1)); } catch (_) {}
    if (!Array.isArray(arr) || arr.length !== 1 || arr[0].id !== 0 || typeof arr[0].uz !== 'string' || !arr[0].uz.trim()) throw new Error('Javob tarjima JSON formatiga mos emas. Boshqa modelni sinang.');
    $('sampleUz').textContent = arr[0].uz; $('sampleEn').textContent = TEST_EN; $('sample').style.display = 'block';
    markStep('step3', true);
    say($('testMsg'), `Ishladi. Tokenlar: ${res.usage?.input_tokens ?? '?'} kirish, ${res.usage?.output_tokens ?? '?'} chiqish.`, 'ok');
  } finally { if (token === epoch) controls(false); }
});
async function loadTuning() {
  const { tuning } = await chrome.storage.local.get('tuning');
  for (const [key, value] of Object.entries({ ...TUNING_DEFAULTS, ...(tuning || {}) })) if ($(key)) $(key).value = value;
}
on('saveTuning', 'click', 'tuningMsg', async () => {
  const tuning = {};
  tuning.translationMode = $('translationMode').value === 'stream' ? 'stream' : 'whole';
  for (const [id, min, max] of [['batchSize', 1, 40], ['concurrency', 1, 3], ['lengthRatio', 0.8, 1.6], ['gapMs', 0, 30000], ['temperature', 0, 1]]) {
    const v = Number($(id).value);
    tuning[id] = Number.isFinite(v) && v >= min && v <= max ? v : TUNING_DEFAULTS[id];
  }
  tuning.concurrency = Math.round(tuning.concurrency); tuning.batchSize = Math.round(tuning.batchSize); tuning.gapMs = Math.round(tuning.gapMs);
  await chrome.storage.local.set({ tuning }); await loadTuning(); say($('tuningMsg'), 'Saqlandi.', 'ok');
});
on('openLab', 'click', 'testMsg', () => window.open(chrome.runtime.getURL('tts-lab.html'), '_blank'));
async function refreshCache() {
  const all = await chrome.storage.local.get(null), keys = Object.keys(all).filter(k => k.startsWith('tr:'));
  let total = 0, translated = 0;
  for (const key of keys) {
    const segs = Array.isArray(all[key]?.segs) ? all[key].segs : [];
    total += segs.length;
    for (const seg of segs) if (seg?.uz) translated++;
  }
  $('cacheInfo').textContent = keys.length ? `${keys.length} ta ma’ruza · ${translated}/${total} segment tarjima qilingan` : 'Hali hech narsa saqlanmagan.';
  $('clearCache').disabled = !keys.length;
}
on('clearCache', 'click', 'cacheMsg', async () => {
  if (!window.confirm('Barcha saqlangan tarjimalar o‘chirilsinmi?')) return;
  const all = await chrome.storage.local.get(null), keys = Object.keys(all).filter(k => k.startsWith('tr:'));
  await chrome.storage.local.remove(keys); await refreshCache(); say($('cacheMsg'), `${keys.length} ta ma’ruza o‘chirildi.`, 'ok');
});
(async () => {
  controls(true);
  try {
    const data = await chrome.storage.local.get('provider');
    provider = validProvider(data.provider) ? data.provider : 'anthropic';
    $('provider').value = provider; $('keyLink').href = Providers[provider].keyUrl;
    await loadTuning(); await refreshCache(); controls(false); await refresh();
    $('model').replaceChildren(modelOption(currentModel, currentModel || '— ro‘yxatni yuklang —'));
    if (hasKey) await loadModels();
  } catch (error) { controls(false); say($('keyMsg'), error.message, 'err'); }
})();
