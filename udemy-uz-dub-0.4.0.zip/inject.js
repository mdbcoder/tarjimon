// MAIN world: faqat joriy darsning subtitr manzillarini uzatadi.
(() => {
  "use strict";
  const lecture = () => (location.pathname.match(/\/lecture\/(\d+)/) || [])[1] || null;
  let current = lecture();
  let since = 0;
  const candidates = new Map();
  const owners = new Map();

  function syncLecture() {
    const id = lecture();
    if (id === current) return;
    for (const url of candidates.keys()) owners.set(url, current);
    current = id;
    since = performance.now();
    candidates.clear();
  }

  function report(input, lang = "") {
    syncLecture();
    if (!current) return;
    let url;
    try {
      url = new URL(input, location.href);
      if (url.protocol !== "https:" || !/(^|\.)(udemy\.com|udemycdn\.com)$/.test(url.hostname) ||
          !url.pathname.toLowerCase().endsWith(".vtt") || url.pathname.includes("thumb-sprites")) return;
    } catch { return; }
    if (owners.has(url.href) && owners.get(url.href) !== current) return;
    const track = Array.from(document.querySelectorAll("video track")).find((t) => t.src === url.href);
    lang = track?.srclang || lang;
    if (lang && !/^en(?:[-_]|$)/i.test(lang)) return;
    candidates.set(url.href, lang);
    window.postMessage({ __uzdub: "vtt", url: url.href, lang, lectureId: current }, location.origin);
  }

  const origFetch = window.fetch;
  window.fetch = function (input) {
    try { report(typeof input === "string" || input instanceof URL ? String(input) : input?.url); } catch {}
    return origFetch.apply(this, arguments);
  };
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try { report(String(url)); } catch {}
    return origOpen.apply(this, arguments);
  };

  function scan() {
    syncLecture();
    for (const item of performance.getEntriesByType("resource")) {
      if (item.startTime >= since) report(item.name);
    }
    // English trekni oxirida yuborish orqali unga ustuvorlik beramiz.
    for (const t of document.querySelectorAll("video track")) {
      if (/^en(?:[-_]|$)/i.test(t.srclang)) report(t.src, t.srclang);
    }
  }
  setInterval(scan, 2000);
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.origin !== location.origin || e.data?.__uzdub !== "reset") return;
    syncLecture();
    for (const [url, lang] of candidates) report(url, lang);
    scan();
  });
  scan();
})();
